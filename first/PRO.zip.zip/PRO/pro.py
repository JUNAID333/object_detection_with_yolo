from flask import Flask, render_template, request, redirect, url_for, send_from_directory
import base64, os

route=os.path.dirname(os.path.abspath(__file__))
des="".join([route,"test.jpeg"])



app = Flask(__name__)

@app.route('/')
@app.route('/home')
def home():
	return render_template('home.html')

@app.route('/cam')
def Camera():
	return render_template('cam.html')


@app.route('/saveimage',methods=['POST'])
def saveImage():
	data_url = request.values['imageBase64']
	image_encoded = data_url.split(',')[1]
	body = base64.b64decode(image_encoded.encode('utf-8'))
	file=open("test.jpeg","wb")
	file.write(body)
	#return redirect(url_for('imageProcess'))

	

# @app.route('/process')	
# def imageProcess():

	


	

if __name__ == '__main__':
	app.debug = True
	app.run(host='0.0.0.0', port=8000)


